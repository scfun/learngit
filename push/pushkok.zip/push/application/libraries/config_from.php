<?php
	class config_from{
	
		public function __construct(){
			
		}
		/*
		 * 获取APPform表单规则
		 */
		function get_app_form_config(){
			$config = array();
		}
	}