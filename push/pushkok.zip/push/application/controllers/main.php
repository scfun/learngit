<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Main extends CI_Controller{
		
		function index(){
			//@TODO
			$this->load->model('task_model');
			$data['task_count']=$this->task_model->get_task_count();
			$data['sucess_task_count']=$this->task_model->get_success_task();
			$this->load->view('header');
			$this->load->view('index',$data);
			$this->load->view('message_modal');
		}
		function test(){
			
		}
	}