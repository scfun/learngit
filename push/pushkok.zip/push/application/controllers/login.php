<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Login extends CI_Controller{
		function Index($error=null){
			$data['error'] =$error;
			$this->load->view('login',$data);
		}
	}