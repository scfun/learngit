<?php
require APPPATH.'/libraries/XingeApp.php';
	class Task_list extends CI_Controller{
		function index(){
			$this->load->model('task_model');
			$data['task_info'] = $this->task_model->get_task_info();
			$this->load->view('header');
			$this->load->view('task_list',$data);
			$this->load->view('message_modal');
			
		}
		function add_task(){
			$res = $this->input->post();
			$push=$this->set_task();
			$mess = $this->set_task_mess(1, $res['title'], $res['content'],$res['url'],null);
			//$res = $this->XingeApp->PushTags(0,array('debug'),$this->message);
			//$push = $this->set_task();
			//$mess = $this->set_task_mess(1, "hi", "hi", "com.sss",null);
			$ret = $push->PushTags(0, array('debug'),'OR', $mess);
			$res['ret_code']=$ret['ret_code'];
			$res['push_id']=$ret['result']['push_id'];
			$this->load->model('task_model');
			$booleam = $this->task_model->insert_task($res);
		}
		function set_task_mess($task_type,$title,$content,$url,$setSendTime){
			$mess = new Message();
			if($task_type = 1){
				$mess->setType(Message::TYPE_NOTIFICATION);
			}elseif($task_type =2){
				$mess->setType(Message::TYPE_MESSAGE);
			}
			$mess->setTitle($title);
			$mess->setContent($content);
			$custom = array('url'=>$url);
			$mess->setCustom($custom);
			$mess->setSendTime($setSendTime=null);
			return $mess;
		}
		function set_task(){
			$res = $this->app_model->get_app_info();
			$params = array('accessId'=>$res[0]['access_id'],
							'secretKey'=>$res[0]['secret_key']);
			$push = new XingeApp($params);
			return $push;
		}
		function query_status($push_id_list){
			$push = $this->set_task();
			$ret = $push->QueryPushStatus(array('30737721'));
			print_r($ret);
		}
	}
	?>