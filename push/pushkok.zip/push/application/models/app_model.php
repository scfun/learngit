<?php

	class App_model extends CI_Model{
		var $tb_name = 'push_apps_info';
		public function __construct(){
			parent::__construct();
		}
		public function insert_app_info($app_info){
			$data = array(
					'appName' => $app_info['app_name'],
					'packageName'=> $app_info['package_name'],
					'access_id'=> $app_info['access_id'],
					'access_key'=> $app_info['access_key'],
					'secret_key'=> $app_info['secret_key'],
					'createTime'=>date('Y-m-d H:i:s',time()),
					);
			$booleam = $this->db->insert($this->tb_name,$data);
			return $booleam;
		}
		public function get_app_info($limit=null,$offset=null){
			$res = $this->db->get($this->tb_name,$limit,$offset)->result_array();
			return $res;
		}
	}