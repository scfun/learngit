<!-- 右侧导航 -->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 sidebar">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">操作什么</h3>
                </div>
                <div class="panel-body">
                    <ul class="nav nav-sidebar">
                        <li><a href="#">报告(未开)</a></li>
                        <li><a href="#">分析(未开)</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">今日动态</h3>
                </div>
                <div class="panel-body"><h5>暂未开放</h5></div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">计划任务</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                    </div>
                    <div class="row">
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                        <div class="col-xs-1 date well">2015-03-20</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Task统计</h3>
                </div>
                <div class="panel-body">
                    <table class="table table-hover">
                        <tr calss="active">
                            <td>任务总数</td>
                            <td><?php echo $task_count[0]['count(*)'] ?></td>
                        </tr>
                        <tr class="success">
                            <td>成功数</td>
                            <td><?php echo $sucess_task_count[0]['count(*)'] ?></td>
                        </tr>
                        <tr class="info">
                            <td>待发送</td>
                            <td>0</td>
                        </tr>
                    </table>
                </div>
                <div class="panel-heading">
                    <h3 class="panel-title">最近Task</h3>
                </div>
                <div class="panel-body">
                    <ul class="list-group">
                        <li class="list-group-item list-group-item-success">
                            <div><s class="text-left">push泰国用户</s>
                            </div>
                            <span class="text-right">2015-3-2</span>
                        </li>
                        <li class="list-group-item list-group-item-info">
                            <div><s class="text-left">push泰国用户</s>
                            </div>
                            <span class="text-right">2015-3-2</span>
                        </li>
                        <li class="list-group-item list-group-item-warning">
                            <div><s class="text-left">push泰国用户</s>
                            </div>
                            <span class="text-right">2015-3-2</span></li>
                        <li class="list-group-item list-group-item-danger">
                            <div><s class="text-left">push泰国用户</s>
                            </div>
                            <span class="text-right">2015-3-2</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>